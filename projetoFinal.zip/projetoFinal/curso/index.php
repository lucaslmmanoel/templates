<?php
include_once '../Conexao.php';
$conexao = new Conexao();

$sql = "select * from curso";
$cursos = $conexao->recuperarDados($sql);

include_once '../cabecalho.php';
?>

    <h1 class="text-center">Cursos</h1>

    <table class="table table-bordered table-hover table-striped table-condensed">
        <tr>
            <td>Id</td>
            <td>Nome</td>
        </tr>

        <?php foreach ($cursos as $curso){
            echo "
            <tr>
                <td>{$curso['id_curso']}</td>
                <td>{$curso['nome']}</td>
            </tr>
        ";
        } ?>

    </table>

<?php
include_once '../rodape.php';